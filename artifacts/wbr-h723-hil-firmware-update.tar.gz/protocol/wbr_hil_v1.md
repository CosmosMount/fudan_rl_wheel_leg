# WBR STM32 HIL protocol v1

This protocol carries one WBR policy inference at a time over USB CDC ACM. The
transport is a byte stream: USB packet boundaries have no framing meaning.

## Scalar encoding and frame

All integers and IEEE-754 binary32 values are little-endian. A receiver must
decode integers explicitly and copy float bit patterns with `memcpy`; it must
not cast an unaligned byte buffer to a packed C structure or `float *`.

Each frame is:

| Offset | Type | Field |
| ---: | --- | --- |
| 0 | `u32` | magic `0x314c5257` (wire bytes `57 52 4c 31`, `WRL1`) |
| 4 | `u8` | protocol version, exactly `1` |
| 5 | `u8` | message type, `1` through `5` |
| 6 | `u16` | payload length, at most `608` |
| 8 | `u32` | request sequence |
| 12 | bytes | payload |
| `12 + length` | `u16` | CRC footer |

The CRC is reflected CRC-16 with polynomial `0x8408`, seed `0xffff`, and no
final XOR. It covers the complete 12-byte header followed by the payload; the
CRC footer itself is excluded. The footer is little-endian. The check value for
ASCII `123456789` is `0x6f91`.

The canonical cross-language `HELLO_REQ` test vector uses sequence `1` and
session `0x11223344`; its complete frame is:

```text
57524c31010110000100000044332211102700000fe4281c010000004167
```

The parser scans for magic, validates version/type/length before trusting the
length, accepts arbitrary fragmentation, and resynchronizes after garbage,
invalid headers, and CRC errors. A link reset discards every partial frame.

A complete, CRC-valid `HELLO_REQ` is also a synchronization barrier. While the
receiver is waiting for the remainder of an older incomplete frame, finding
such a 30-byte HELLO at a nonzero buffered offset takes precedence over the
older candidate frame, discards every preceding byte, and is processed
immediately. This recovers in one handshake if a host
times out after writing only part of a 608-byte inference request. Magic or a
HELLO-shaped byte sequence without a valid CRC is not a barrier.

## Fixed contract

| Name | Value |
| --- | ---: |
| policy period | `10000 us` |
| model-set ID | `0x1c28e40f` |
| strict flags | `0x00000001` |
| capabilities | `0x0000000f` |
| observation width | `25` float32 |
| history width | `125` float32 |
| action width | `6` float32 |
| modes | bit mask `3`: plane `0`, jump `1` |
| maximum payload | `608` bytes |

The exact generated policies covered by model-set ID `0x1c28e40f` are:

| Source model | SHA-256 |
| --- | --- |
| `plane_15000.onnx` | `d794155543e4529e169b4bf68446f5ef8eef37a6096fad91c3de5d998edf8c0f` |
| `jump_25400.onnx` | `fe640156c2df66cc9090834191138c24bed4bad8774e8c392a8c0d07a5c32465` |

Regenerating either X-CUBE-AI model requires changing both firmware
`WBR_HIL_MODEL_SET_ID` and host `MODEL_SET_ID`, even when tensor dimensions are
unchanged. This makes a same-shape, wrong-weight firmware fail the handshake.

The history is five 25-value frames in oldest-to-newest order and includes the
current frame. It is transmitted independently from the clipped current
observation because the policy contract keeps history unclipped.

## Messages

The response header sequence always repeats the triggering request header
sequence. `INFER_RSP.input_sequence` repeats it a second time; a host must
require both values to match its sole outstanding request.

### `1 HELLO_REQ`

Payload `<IIII>` (16 bytes):

1. `session`: nonzero host-generated session ID
2. `policy_period_us`: exactly `10000`
3. `model_set`: exactly `0x1c28e40f`
4. `flags`: exactly `1` (strict mode; unknown bits are rejected)

A valid HELLO starts a new session and makes its header sequence the predecessor
of the first inference sequence. A failed HELLO leaves no active session.

### `2 HELLO_RSP`

Payload `<IIIIIHHHHHH>` (32 bytes):

1. session
2. capabilities (`0x0f`)
3. model-set ID
4. policy period in microseconds
5. status
6. observation width (`25`)
7. history width (`125`)
8. action width (`6`)
9. mode mask (`3`)
10. maximum payload (`608`)
11. protocol version (`1`)

Status `0` is success. Other HELLO status values are: `1` zero session, `2`
period mismatch, `3` model-set mismatch, `4` strict-flags mismatch, and `5` AI
runtime/model initialization unavailable. A host must verify every returned
contract field before sending observations.

### `3 INFER_REQ`

Payload `<IB3x150f>` (608 bytes):

1. session
2. mode (`0` plane, `1` jump)
3. three reserved zero bytes
4. 25 observation float32 values
5. 125 history float32 values

Every float must be finite. Within a session, request sequences are strictly
`previous + 1` modulo `2^32`. Only one inference is processed at a time.

### `4 INFER_RSP`

Payload `<IIBBHI6f>` (40 bytes):

1. session
2. input sequence (same as both request and response header sequence)
3. mode
4. status (`0` success, `1` AI execution/output failure)
5. reserved `u16`, zero
6. inference time in microseconds (DWT cycle counter when available)
7. six action float32 values

Actions are finite and clipped to `[-100, 100]`. A failed inference returns a
zero action and nonzero status; the host must not apply it.

### `5 ERROR`

Payload `<IIII>` (16 bytes), preserving the historical field order:

1. session associated with the offending request (or zero if unavailable)
2. error code
3. detail
4. offending request sequence

The ERROR header sequence also repeats the offending request sequence. Error
codes are: `1` bad length, `2` request type not accepted, `3` HELLO required,
`4` session mismatch, `5` non-consecutive/stale sequence, `6` bad mode, `7`
nonzero reserved bytes, and `8` non-finite input. For a bad length, detail packs
`expected << 16 | actual`; for a non-finite input it is the zero-based index in
the concatenated 150 floats. Sending an ERROR invalidates the active session;
the host must perform HELLO again.

## USB and timeout behavior

The STM32 reads CDC data in 64-byte chunks and feeds every received byte to the
stream parser. Reads retain USBX's blocking `WAIT_FOREVER` behavior; class
deactivation/USBX aborts a pending read on disconnect. Writes have a 100 ms
ThreadX timeout. A stable-link write timeout or failure aborts the transmit pipe
and drains its completion semaphore so a late completion cannot satisfy the
next transfer.

Disconnects, failed writes, and other transport errors reset the parser and
session. Activate/deactivate callbacks only atomically publish or withdraw the
CDC instance and advance a generation counter. The worker validates both the
handle and generation after every blocking transfer, so it drops an obsolete
result without issuing IOCTLs or touching an old instance. Inference always
runs synchronously in the USB application thread, never in a USB callback.

## Host protocol tests

The framing and session engine have no STM32, USBX, or X-CUBE-AI dependency.
Run the native tests either from the repository root:

```sh
cmake -S . -B build/host-tests -DWBR_BUILD_HOST_TESTS=ON
cmake --build build/host-tests
ctest --test-dir build/host-tests --output-on-failure
```

or directly with `cmake -S tests -B build/host-tests`. Tests cover the golden
CRC/frame bytes, every HELLO split point, garbage and CRC resynchronization,
unknown types, the maximum-size frame, exact handshake fields, sequence wrap,
duplicate/skipped sequences, session mismatch, non-finite tensors, action
clipping, and fail-closed errors.
