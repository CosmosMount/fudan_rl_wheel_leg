# WBR STM32H723 HIL firmware

This repository builds the STM32H723 side of the WBR USB hardware-in-the-loop
(HIL) path. The host keeps MuJoCo, observation/history construction, validation,
and motor control; the MCU receives one request at a time, runs the selected
X-CUBE-AI plane or jump policy, and returns six actions over USB CDC ACM.

The HIL-specific layout is:

- `app/hil/`: stream parser, session engine, X-CUBE-AI adapter, and USB worker.
- `protocol/wbr_hil_v1.md`: exact v1 wire contract and model identity hashes.
- `tests/`: hardware-independent protocol and session tests runnable with a
  native C compiler.
- `board/X-CUBE-AI/App/`: generated `plane` and `jump` network sources used by
  the adapter.

## Test the protocol on Linux

Run these tests before installing an embedded toolchain or connecting a board:

```sh
cmake -S . -B build/host-tests \
  -DWBR_BUILD_HOST_TESTS=ON -DCMAKE_BUILD_TYPE=Debug
cmake --build build/host-tests --parallel
ctest --test-dir build/host-tests --output-on-failure
```

They exercise CRC/framing and fragmentation/resynchronization as well as the
strict handshake, sequence/session checks, finite-value checks, and action
clipping.

## Build and flash the STM32 firmware

Install the GNU Arm Embedded Toolchain (`arm-none-eabi-gcc`), CMake 3.22 or
newer, and Ninja, then verify the compiler is on `PATH` and build:

```sh
arm-none-eabi-gcc --version
cmake --preset Release
cmake --build --preset Release
```

The linked image is `build/Release/wbr_rl_deploy.elf`. If a raw binary is needed
by the chosen programmer, create it with:

```sh
arm-none-eabi-objcopy -O binary \
  build/Release/wbr_rl_deploy.elf build/Release/wbr_rl_deploy.bin
```

Flash the ELF (or converted BIN at the linker-script flash base) with the
project's normal ST-LINK/debugger or STM32CubeProgrammer workflow, reset the
board, and then connect its USB device port. Do not replace either generated AI
model without also updating the firmware and host model-set IDs described in
the protocol document.

## Connect the Linux host

After reset, confirm that the CDC device enumerated:

```sh
ls -l /dev/ttyACM*
```

The current HIL image identifies itself as USB VID:PID `0483:5710` with product
string `WBR-H723-HIL-v1`. If the product is still `Doraemon`, the board is
running the pre-HIL base image and must be rebuilt and flashed from this
repository.

If the device exists but cannot be opened, check membership of the distribution's
serial-device group (commonly `dialout`). For example, add the login user with
`sudo usermod -aG dialout <username>`, then log out and back in. Also make sure a
serial console or modem-management service is not holding the selected port.

Use this startup order:

1. Build and flash this firmware, reset the STM32, and connect USB.
2. Confirm the actual `/dev/ttyACM*` path and access permissions.
3. In `fudan_rl`, activate its `wbr` environment and install the HIL dependency
   plus the editable package:

   ```sh
   python -m pip install 'pyserial>=3.5,<4'
   python -m pip install --no-deps -e .
   ```

4. Start the synchronous MuJoCo HIL client, choosing the enumerated port:

   ```sh
   sim2hil-wbr --port /dev/ttyACM0 --mode plane
   # or: sim2hil-wbr --port /dev/ttyACM0 --mode jump
   ```

The initial HELLO verifies the protocol version, both tensor dimensions, policy
period, capabilities, and exact model-set identity before inference is allowed.
A communication or validation failure invalidates the session; the host does
not step MuJoCo with an old action.

The native protocol tests do not constitute hardware validation. Confirm USB
enumeration, both policies, timing, disconnect/reconnect behavior, and safe
failure semantics on the target board before treating the HIL path as verified.
