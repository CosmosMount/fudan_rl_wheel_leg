#include "wbr_hil_service.h"

#include "tx_api.h"
#include "ux_api.h"
#include "ux_device_class_cdc_acm.h"
#include "wbr_hil_ai.h"
#include "wbr_hil_engine.h"

#include <stdatomic.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define WBR_HIL_USB_READ_SIZE ((ULONG)64)

static _Atomic(uintptr_t) g_published_cdc;
static _Atomic(uint32_t) g_cdc_generation;
static wbr_hil_engine_t g_engine;
static uint8_t g_usb_read_buffer[WBR_HIL_USB_READ_SIZE];
static bool g_ai_ready;
static bool g_service_initialized;

typedef struct {
  UX_SLAVE_CLASS_CDC_ACM *cdc;
  uint32_t generation;
} wbr_hil_cdc_link_t;

static wbr_hil_cdc_link_t g_writer_link;

void wbr_hil_service_initialize(void) {
  if (!g_service_initialized) {
    g_ai_ready = wbr_hil_ai_init();
    g_service_initialized = true;
  }
}

void wbr_hil_usb_cdc_activate(void *cdc_instance) {
  TX_INTERRUPT_SAVE_AREA
  TX_DISABLE
  atomic_store_explicit(&g_published_cdc, (uintptr_t)cdc_instance, memory_order_release);
  (void)atomic_fetch_add_explicit(&g_cdc_generation, 1U, memory_order_acq_rel);
  TX_RESTORE
}

void wbr_hil_usb_cdc_deactivate(void *cdc_instance) {
  uintptr_t expected = (uintptr_t)cdc_instance;
  TX_INTERRUPT_SAVE_AREA
  TX_DISABLE
  if (atomic_compare_exchange_strong_explicit(
          &g_published_cdc,
          &expected,
          (uintptr_t)0U,
          memory_order_acq_rel,
          memory_order_acquire)) {
    (void)atomic_fetch_add_explicit(&g_cdc_generation, 1U, memory_order_acq_rel);
  }
  TX_RESTORE
}

static wbr_hil_cdc_link_t published_link(void) {
  wbr_hil_cdc_link_t link;
  uint32_t generation_after;
  do {
    link.generation = atomic_load_explicit(&g_cdc_generation, memory_order_acquire);
    link.cdc = (UX_SLAVE_CLASS_CDC_ACM *)atomic_load_explicit(
        &g_published_cdc, memory_order_acquire);
    generation_after = atomic_load_explicit(&g_cdc_generation, memory_order_acquire);
  } while (link.generation != generation_after);
  return link;
}

static bool link_is_current(const wbr_hil_cdc_link_t *link) {
  if (link == NULL || link->cdc == UX_NULL) {
    return false;
  }
  const uint32_t generation_before =
      atomic_load_explicit(&g_cdc_generation, memory_order_acquire);
  const uintptr_t cdc = atomic_load_explicit(&g_published_cdc, memory_order_acquire);
  const uint32_t generation_after =
      atomic_load_explicit(&g_cdc_generation, memory_order_acquire);
  return generation_before == link->generation && generation_after == link->generation &&
         cdc == (uintptr_t)link->cdc;
}

static bool links_equal(const wbr_hil_cdc_link_t *left, const wbr_hil_cdc_link_t *right) {
  return left->cdc == right->cdc && left->generation == right->generation;
}

static UX_SLAVE_ENDPOINT *cdc_endpoint(UX_SLAVE_CLASS_CDC_ACM *cdc, ULONG direction) {
  if (cdc == UX_NULL || cdc->ux_slave_class_cdc_acm_interface == UX_NULL) {
    return UX_NULL;
  }
  UX_SLAVE_ENDPOINT *endpoint =
      cdc->ux_slave_class_cdc_acm_interface->ux_slave_interface_first_endpoint;
  if (endpoint == UX_NULL) {
    return UX_NULL;
  }
  if ((endpoint->ux_slave_endpoint_descriptor.bEndpointAddress & UX_ENDPOINT_DIRECTION) != direction) {
    endpoint = endpoint->ux_slave_endpoint_next_endpoint;
    if (endpoint == UX_NULL) {
      return UX_NULL;
    }
  }
  if ((endpoint->ux_slave_endpoint_descriptor.bEndpointAddress & UX_ENDPOINT_DIRECTION) != direction) {
    return UX_NULL;
  }
  return endpoint;
}

static void abort_xmit_and_drain(const wbr_hil_cdc_link_t *link) {
  UX_SLAVE_TRANSFER *transfer = UX_NULL;
  TX_INTERRUPT_SAVE_AREA
  TX_DISABLE

  if (!link_is_current(link)) {
    TX_RESTORE
    return;
  }
  UX_SLAVE_ENDPOINT *const endpoint = cdc_endpoint(link->cdc, UX_ENDPOINT_IN);
  if (endpoint == UX_NULL || !link_is_current(link)) {
    TX_RESTORE
    return;
  }
  transfer = &endpoint->ux_slave_endpoint_transfer_request;
  (void)ux_device_class_cdc_acm_ioctl(
      link->cdc,
      UX_SLAVE_CLASS_CDC_ACM_IOCTL_ABORT_PIPE,
      (VOID *)(ALIGN_TYPE)UX_SLAVE_CLASS_CDC_ACM_ENDPOINT_XMIT);
  while (tx_semaphore_get(&transfer->ux_slave_transfer_request_semaphore, TX_NO_WAIT) ==
         TX_SUCCESS) {
  }
  TX_RESTORE
}

static bool configure_write_timeout(const wbr_hil_cdc_link_t *link) {
  UINT status = UX_ERROR;
  TX_INTERRUPT_SAVE_AREA
  TX_DISABLE

  if (!link_is_current(link) || cdc_endpoint(link->cdc, UX_ENDPOINT_IN) == UX_NULL ||
      !link_is_current(link)) {
    TX_RESTORE
    return false;
  }
  status = ux_device_class_cdc_acm_ioctl(
      link->cdc,
      UX_SLAVE_CLASS_CDC_ACM_IOCTL_SET_WRITE_TIMEOUT,
      (VOID *)(ALIGN_TYPE)UX_MS_TO_TICK(100U));
  const bool still_current = link_is_current(link);
  TX_RESTORE
  return still_current && status == UX_SUCCESS;
}

static bool usb_write_all(void *context, const uint8_t *data, size_t length) {
  const wbr_hil_cdc_link_t *const link = (const wbr_hil_cdc_link_t *)context;
  size_t offset = 0U;

  while (offset < length) {
    if (!link_is_current(link)) {
      return false;
    }
    ULONG actual_length = 0U;
    const UINT status = ux_device_class_cdc_acm_write(
        link->cdc,
        (UCHAR *)(data + offset),
        (ULONG)(length - offset),
        &actual_length);
    if (!link_is_current(link)) {
      return false;
    }
    if (status != UX_SUCCESS || actual_length == 0U || actual_length > (ULONG)(length - offset)) {
      abort_xmit_and_drain(link);
      return false;
    }
    offset += (size_t)actual_length;
  }
  return true;
}

void wbr_hil_service_worker(void) {
  wbr_hil_cdc_link_t current_link = {UX_NULL, 0U};

  if (!g_service_initialized) {
    wbr_hil_service_initialize();
  }

  for (;;) {
    const wbr_hil_cdc_link_t available_link = published_link();
    if (available_link.cdc == UX_NULL) {
      if (current_link.cdc != UX_NULL) {
        wbr_hil_engine_reset_link(&g_engine);
        current_link.cdc = UX_NULL;
      }
      (void)tx_thread_sleep(1U);
      continue;
    }

    if (!links_equal(&available_link, &current_link)) {
      if (current_link.cdc != UX_NULL) {
        wbr_hil_engine_reset_link(&g_engine);
      }
      current_link = available_link;
      if (!configure_write_timeout(&current_link)) {
        wbr_hil_engine_reset_link(&g_engine);
        current_link.cdc = UX_NULL;
        (void)tx_thread_sleep(1U);
        continue;
      }
      g_writer_link = current_link;
      wbr_hil_engine_init(
          &g_engine, wbr_hil_ai_infer, UX_NULL, usb_write_all, &g_writer_link, g_ai_ready);
    }

    ULONG actual_length = 0U;
    const UINT status = ux_device_class_cdc_acm_read(
        current_link.cdc, g_usb_read_buffer, WBR_HIL_USB_READ_SIZE, &actual_length);
    if (!link_is_current(&current_link)) {
      wbr_hil_engine_reset_link(&g_engine);
      current_link.cdc = UX_NULL;
      continue;
    }
    if (status != UX_SUCCESS) {
      wbr_hil_engine_reset_link(&g_engine);
      current_link.cdc = UX_NULL;
      (void)tx_thread_sleep(1U);
      continue;
    }
    if (actual_length > WBR_HIL_USB_READ_SIZE ||
        (actual_length > 0U &&
         !wbr_hil_engine_feed(&g_engine, g_usb_read_buffer, (size_t)actual_length))) {
      wbr_hil_engine_reset_link(&g_engine);
      current_link.cdc = UX_NULL;
    }
  }
}
