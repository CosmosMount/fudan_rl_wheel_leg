#ifndef WBR_HIL_SERVICE_H
#define WBR_HIL_SERVICE_H

#ifdef __cplusplus
extern "C" {
#endif

void wbr_hil_usb_cdc_activate(void *cdc_instance);
void wbr_hil_usb_cdc_deactivate(void *cdc_instance);
void wbr_hil_service_initialize(void);
void wbr_hil_service_worker(void);

#ifdef __cplusplus
}
#endif

#endif
