#ifndef WBR_HIL_PROTOCOL_H
#define WBR_HIL_PROTOCOL_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define WBR_HIL_MAGIC UINT32_C(0x314C5257)
#define WBR_HIL_VERSION UINT8_C(1)
#define WBR_HIL_HEADER_SIZE ((size_t)12)
#define WBR_HIL_CRC_SIZE ((size_t)2)
#define WBR_HIL_MAX_PAYLOAD ((size_t)608)
#define WBR_HIL_MAX_FRAME_SIZE (WBR_HIL_HEADER_SIZE + WBR_HIL_MAX_PAYLOAD + WBR_HIL_CRC_SIZE)

enum {
  WBR_HIL_MSG_HELLO_REQ = 1,
  WBR_HIL_MSG_HELLO_RSP = 2,
  WBR_HIL_MSG_INFER_REQ = 3,
  WBR_HIL_MSG_INFER_RSP = 4,
  WBR_HIL_MSG_ERROR = 5,
};

typedef struct {
  uint8_t type;
  uint16_t payload_length;
  uint32_t sequence;
  const uint8_t *payload;
} wbr_hil_frame_view_t;

typedef void (*wbr_hil_frame_callback_t)(void *context, const wbr_hil_frame_view_t *frame);

typedef struct {
  uint8_t bytes[WBR_HIL_MAX_FRAME_SIZE];
  size_t used;
  uint32_t discarded_bytes;
  uint32_t bad_headers;
  uint32_t bad_crcs;
} wbr_hil_parser_t;

uint16_t wbr_hil_crc16(const uint8_t *data, size_t length);

uint16_t wbr_hil_get_u16_le(const uint8_t *data);
uint32_t wbr_hil_get_u32_le(const uint8_t *data);
void wbr_hil_put_u16_le(uint8_t *data, uint16_t value);
void wbr_hil_put_u32_le(uint8_t *data, uint32_t value);

void wbr_hil_parser_reset(wbr_hil_parser_t *parser);
size_t wbr_hil_parser_feed(
    wbr_hil_parser_t *parser,
    const uint8_t *data,
    size_t length,
    wbr_hil_frame_callback_t callback,
    void *context);

size_t wbr_hil_frame_encode(
    uint8_t type,
    uint32_t sequence,
    const uint8_t *payload,
    uint16_t payload_length,
    uint8_t *output,
    size_t output_capacity);

#ifdef __cplusplus
}
#endif

#endif
