#include "wbr_hil_protocol.h"

#include <string.h>

static const uint8_t k_magic_bytes[4] = {0x57U, 0x52U, 0x4CU, 0x31U};

#define WBR_HIL_SYNC_HELLO_PAYLOAD_SIZE ((uint16_t)16)
#define WBR_HIL_SYNC_HELLO_FRAME_SIZE \
  (WBR_HIL_HEADER_SIZE + (size_t)WBR_HIL_SYNC_HELLO_PAYLOAD_SIZE + WBR_HIL_CRC_SIZE)

uint16_t wbr_hil_crc16(const uint8_t *data, size_t length) {
  uint16_t crc = UINT16_C(0xFFFF);

  for (size_t i = 0; i < length; ++i) {
    crc ^= data[i];
    for (unsigned bit = 0; bit < 8U; ++bit) {
      crc = (crc & 1U) != 0U ? (uint16_t)((crc >> 1U) ^ UINT16_C(0x8408))
                             : (uint16_t)(crc >> 1U);
    }
  }
  return crc;
}

uint16_t wbr_hil_get_u16_le(const uint8_t *data) {
  return (uint16_t)((uint16_t)data[0] | ((uint16_t)data[1] << 8U));
}

uint32_t wbr_hil_get_u32_le(const uint8_t *data) {
  return (uint32_t)data[0] | ((uint32_t)data[1] << 8U) | ((uint32_t)data[2] << 16U) |
         ((uint32_t)data[3] << 24U);
}

void wbr_hil_put_u16_le(uint8_t *data, uint16_t value) {
  data[0] = (uint8_t)value;
  data[1] = (uint8_t)(value >> 8U);
}

void wbr_hil_put_u32_le(uint8_t *data, uint32_t value) {
  data[0] = (uint8_t)value;
  data[1] = (uint8_t)(value >> 8U);
  data[2] = (uint8_t)(value >> 16U);
  data[3] = (uint8_t)(value >> 24U);
}

void wbr_hil_parser_reset(wbr_hil_parser_t *parser) {
  if (parser == NULL) {
    return;
  }
  parser->used = 0U;
  parser->discarded_bytes = 0U;
  parser->bad_headers = 0U;
  parser->bad_crcs = 0U;
}

static bool starts_with_magic(const uint8_t *data) {
  return memcmp(data, k_magic_bytes, sizeof(k_magic_bytes)) == 0;
}

static void retain_possible_magic(wbr_hil_parser_t *parser) {
  if (parser->used == 0U) {
    return;
  }

  for (size_t start = 1U; start + sizeof(k_magic_bytes) <= parser->used; ++start) {
    if (starts_with_magic(parser->bytes + start)) {
      parser->discarded_bytes += (uint32_t)start;
      memmove(parser->bytes, parser->bytes + start, parser->used - start);
      parser->used -= start;
      return;
    }
  }

  size_t keep = parser->used < (sizeof(k_magic_bytes) - 1U)
                    ? parser->used
                    : (sizeof(k_magic_bytes) - 1U);
  while (keep > 0U &&
         memcmp(parser->bytes + parser->used - keep, k_magic_bytes, keep) != 0) {
    --keep;
  }
  parser->discarded_bytes += (uint32_t)(parser->used - keep);
  if (keep > 0U) {
    memmove(parser->bytes, parser->bytes + parser->used - keep, keep);
  }
  parser->used = keep;
}

static bool header_is_sane(const wbr_hil_parser_t *parser, uint16_t *payload_length) {
  if (parser->bytes[4] != WBR_HIL_VERSION || parser->bytes[5] < WBR_HIL_MSG_HELLO_REQ ||
      parser->bytes[5] > WBR_HIL_MSG_ERROR) {
    return false;
  }
  *payload_length = wbr_hil_get_u16_le(parser->bytes + 6U);
  return (size_t)*payload_length <= WBR_HIL_MAX_PAYLOAD;
}

static size_t complete_hello_barrier_at_tail(const wbr_hil_parser_t *parser) {
  if (parser->used <= WBR_HIL_SYNC_HELLO_FRAME_SIZE) {
    return 0U;
  }

  const size_t start = parser->used - WBR_HIL_SYNC_HELLO_FRAME_SIZE;
  const uint8_t *const candidate = parser->bytes + start;
  if (!starts_with_magic(candidate) || candidate[4] != WBR_HIL_VERSION ||
      candidate[5] != WBR_HIL_MSG_HELLO_REQ ||
      wbr_hil_get_u16_le(candidate + 6U) != WBR_HIL_SYNC_HELLO_PAYLOAD_SIZE) {
    return 0U;
  }

  const uint16_t expected_crc =
      wbr_hil_get_u16_le(candidate + WBR_HIL_SYNC_HELLO_FRAME_SIZE - WBR_HIL_CRC_SIZE);
  const uint16_t actual_crc =
      wbr_hil_crc16(candidate, WBR_HIL_SYNC_HELLO_FRAME_SIZE - WBR_HIL_CRC_SIZE);
  return expected_crc == actual_crc ? start : 0U;
}

static size_t parse_available(
    wbr_hil_parser_t *parser, wbr_hil_frame_callback_t callback, void *context) {
  size_t emitted = 0U;

  for (;;) {
    if (parser->used < sizeof(k_magic_bytes)) {
      return emitted;
    }
    if (!starts_with_magic(parser->bytes)) {
      retain_possible_magic(parser);
      continue;
    }
    if (parser->used < WBR_HIL_HEADER_SIZE) {
      return emitted;
    }

    uint16_t payload_length = 0U;
    if (!header_is_sane(parser, &payload_length)) {
      ++parser->bad_headers;
      ++parser->discarded_bytes;
      memmove(parser->bytes, parser->bytes + 1U, parser->used - 1U);
      --parser->used;
      retain_possible_magic(parser);
      continue;
    }

    const size_t frame_size = WBR_HIL_HEADER_SIZE + (size_t)payload_length + WBR_HIL_CRC_SIZE;
    const size_t hello_offset = complete_hello_barrier_at_tail(parser);
    if (hello_offset > 0U) {
      parser->discarded_bytes += (uint32_t)hello_offset;
      memmove(parser->bytes, parser->bytes + hello_offset, parser->used - hello_offset);
      parser->used -= hello_offset;
      continue;
    }
    if (parser->used < frame_size) {
      return emitted;
    }

    const uint16_t expected_crc = wbr_hil_get_u16_le(parser->bytes + frame_size - 2U);
    const uint16_t actual_crc = wbr_hil_crc16(parser->bytes, frame_size - 2U);
    if (expected_crc != actual_crc) {
      ++parser->bad_crcs;
      ++parser->discarded_bytes;
      memmove(parser->bytes, parser->bytes + 1U, parser->used - 1U);
      --parser->used;
      retain_possible_magic(parser);
      continue;
    }

    const wbr_hil_frame_view_t frame = {
        .type = parser->bytes[5],
        .payload_length = payload_length,
        .sequence = wbr_hil_get_u32_le(parser->bytes + 8U),
        .payload = parser->bytes + WBR_HIL_HEADER_SIZE,
    };
    if (callback != NULL) {
      callback(context, &frame);
    }
    ++emitted;

    const size_t remaining = parser->used - frame_size;
    if (remaining > 0U) {
      memmove(parser->bytes, parser->bytes + frame_size, remaining);
    }
    parser->used = remaining;
  }
}

size_t wbr_hil_parser_feed(
    wbr_hil_parser_t *parser,
    const uint8_t *data,
    size_t length,
    wbr_hil_frame_callback_t callback,
    void *context) {
  if (parser == NULL || (length > 0U && data == NULL)) {
    return 0U;
  }

  size_t emitted = parse_available(parser, callback, context);
  for (size_t i = 0; i < length; ++i) {
    if (parser->used == WBR_HIL_MAX_FRAME_SIZE) {
      ++parser->bad_headers;
      ++parser->discarded_bytes;
      memmove(parser->bytes, parser->bytes + 1U, parser->used - 1U);
      --parser->used;
      retain_possible_magic(parser);
    }
    parser->bytes[parser->used++] = data[i];
    emitted += parse_available(parser, callback, context);
  }
  return emitted;
}

size_t wbr_hil_frame_encode(
    uint8_t type,
    uint32_t sequence,
    const uint8_t *payload,
    uint16_t payload_length,
    uint8_t *output,
    size_t output_capacity) {
  const size_t frame_size = WBR_HIL_HEADER_SIZE + (size_t)payload_length + WBR_HIL_CRC_SIZE;
  if ((size_t)payload_length > WBR_HIL_MAX_PAYLOAD || output == NULL ||
      output_capacity < frame_size || (payload_length > 0U && payload == NULL)) {
    return 0U;
  }

  wbr_hil_put_u32_le(output, WBR_HIL_MAGIC);
  output[4] = WBR_HIL_VERSION;
  output[5] = type;
  wbr_hil_put_u16_le(output + 6U, payload_length);
  wbr_hil_put_u32_le(output + 8U, sequence);
  if (payload_length > 0U) {
    memcpy(output + WBR_HIL_HEADER_SIZE, payload, payload_length);
  }
  wbr_hil_put_u16_le(output + frame_size - 2U, wbr_hil_crc16(output, frame_size - 2U));
  return frame_size;
}
