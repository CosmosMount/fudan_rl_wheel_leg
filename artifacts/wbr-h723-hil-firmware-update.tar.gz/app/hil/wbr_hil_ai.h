#ifndef WBR_HIL_AI_H
#define WBR_HIL_AI_H

#include "wbr_hil_engine.h"

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

bool wbr_hil_ai_init(void);

bool wbr_hil_ai_infer(
    void *context,
    uint8_t mode,
    const float observation[WBR_HIL_OBS_DIM],
    const float history[WBR_HIL_HISTORY_DIM],
    float action[WBR_HIL_ACTION_DIM],
    uint32_t *inference_us);

#ifdef __cplusplus
}
#endif

#endif
