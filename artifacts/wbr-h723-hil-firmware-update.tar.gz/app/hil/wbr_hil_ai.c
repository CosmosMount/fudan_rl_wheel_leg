#include "wbr_hil_ai.h"

#include "jump.h"
#include "jump_data.h"
#include "plane.h"
#include "plane_data.h"
#include "stm32h7xx.h"

#include <math.h>
#include <string.h>

_Static_assert(AI_PLANE_IN_NUM == 2, "plane must have two inputs");
_Static_assert(AI_PLANE_IN_1_SIZE == WBR_HIL_OBS_DIM, "plane obs dimension mismatch");
_Static_assert(AI_PLANE_IN_2_SIZE == WBR_HIL_HISTORY_DIM, "plane history dimension mismatch");
_Static_assert(AI_PLANE_OUT_NUM == 1, "plane must have one output");
_Static_assert(AI_PLANE_OUT_1_SIZE == WBR_HIL_ACTION_DIM, "plane action dimension mismatch");
_Static_assert(AI_PLANE_IN_1_SIZE_BYTES == 4U * WBR_HIL_OBS_DIM, "plane obs type mismatch");
_Static_assert(
    AI_PLANE_IN_2_SIZE_BYTES == 4U * WBR_HIL_HISTORY_DIM, "plane history type mismatch");
_Static_assert(
    AI_PLANE_OUT_1_SIZE_BYTES == 4U * WBR_HIL_ACTION_DIM, "plane action type mismatch");

_Static_assert(AI_JUMP_IN_NUM == 2, "jump must have two inputs");
_Static_assert(AI_JUMP_IN_1_SIZE == WBR_HIL_OBS_DIM, "jump obs dimension mismatch");
_Static_assert(AI_JUMP_IN_2_SIZE == WBR_HIL_HISTORY_DIM, "jump history dimension mismatch");
_Static_assert(AI_JUMP_OUT_NUM == 1, "jump must have one output");
_Static_assert(AI_JUMP_OUT_1_SIZE == WBR_HIL_ACTION_DIM, "jump action dimension mismatch");
_Static_assert(AI_JUMP_IN_1_SIZE_BYTES == 4U * WBR_HIL_OBS_DIM, "jump obs type mismatch");
_Static_assert(
    AI_JUMP_IN_2_SIZE_BYTES == 4U * WBR_HIL_HISTORY_DIM, "jump history type mismatch");
_Static_assert(AI_JUMP_OUT_1_SIZE_BYTES == 4U * WBR_HIL_ACTION_DIM, "jump action type mismatch");

typedef struct {
  ai_handle handle;
  ai_buffer *inputs;
  ai_buffer *outputs;
  bool ready;
} wbr_hil_ai_model_t;

AI_ALIGNED(32)
static ai_u8 g_plane_activations[AI_PLANE_DATA_ACTIVATIONS_SIZE];
AI_ALIGNED(32)
static ai_u8 g_jump_activations[AI_JUMP_DATA_ACTIVATIONS_SIZE];

static wbr_hil_ai_model_t g_plane;
static wbr_hil_ai_model_t g_jump;

static bool buffers_are_valid(const wbr_hil_ai_model_t *model) {
  return model->inputs != NULL && model->outputs != NULL && model->inputs[0].data != NULL &&
         model->inputs[1].data != NULL && model->outputs[0].data != NULL &&
         model->inputs[0].format == AI_BUFFER_FORMAT_FLOAT &&
         model->inputs[1].format == AI_BUFFER_FORMAT_FLOAT &&
         model->outputs[0].format == AI_BUFFER_FORMAT_FLOAT;
}

static bool init_plane(void) {
  const ai_handle activations[] = {AI_HANDLE_PTR(g_plane_activations)};
  const ai_error error = ai_plane_create_and_init(&g_plane.handle, activations, NULL);
  if (error.type != AI_ERROR_NONE || g_plane.handle == AI_HANDLE_NULL) {
    return false;
  }

  ai_u16 input_count = 0U;
  ai_u16 output_count = 0U;
  g_plane.inputs = ai_plane_inputs_get(g_plane.handle, &input_count);
  g_plane.outputs = ai_plane_outputs_get(g_plane.handle, &output_count);
  g_plane.ready = input_count == AI_PLANE_IN_NUM && output_count == AI_PLANE_OUT_NUM &&
                  buffers_are_valid(&g_plane);
  return g_plane.ready;
}

static bool init_jump(void) {
  const ai_handle activations[] = {AI_HANDLE_PTR(g_jump_activations)};
  const ai_error error = ai_jump_create_and_init(&g_jump.handle, activations, NULL);
  if (error.type != AI_ERROR_NONE || g_jump.handle == AI_HANDLE_NULL) {
    return false;
  }

  ai_u16 input_count = 0U;
  ai_u16 output_count = 0U;
  g_jump.inputs = ai_jump_inputs_get(g_jump.handle, &input_count);
  g_jump.outputs = ai_jump_outputs_get(g_jump.handle, &output_count);
  g_jump.ready = input_count == AI_JUMP_IN_NUM && output_count == AI_JUMP_OUT_NUM &&
                 buffers_are_valid(&g_jump);
  return g_jump.ready;
}

static void enable_cycle_counter(void) {
  CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
  DWT->CYCCNT = 0U;
  DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
  __DSB();
  __ISB();
}

bool wbr_hil_ai_init(void) {
  memset(&g_plane, 0, sizeof(g_plane));
  memset(&g_jump, 0, sizeof(g_jump));
  enable_cycle_counter();

  const bool plane_ready = init_plane();
  const bool jump_ready = init_jump();
  return plane_ready && jump_ready;
}

static uint32_t cycles_to_microseconds(uint32_t cycles) {
  if (SystemCoreClock == 0U) {
    return 0U;
  }
  const uint64_t microseconds = ((uint64_t)cycles * UINT64_C(1000000)) / SystemCoreClock;
  return microseconds > UINT32_MAX ? UINT32_MAX : (uint32_t)microseconds;
}

bool wbr_hil_ai_infer(
    void *context,
    uint8_t mode,
    const float observation[WBR_HIL_OBS_DIM],
    const float history[WBR_HIL_HISTORY_DIM],
    float action[WBR_HIL_ACTION_DIM],
    uint32_t *inference_us) {
  (void)context;
  if (observation == NULL || history == NULL || action == NULL || inference_us == NULL) {
    return false;
  }

  wbr_hil_ai_model_t *model = NULL;
  if (mode == WBR_HIL_MODE_PLANE) {
    model = &g_plane;
  } else if (mode == WBR_HIL_MODE_JUMP) {
    model = &g_jump;
  } else {
    return false;
  }
  if (!model->ready) {
    return false;
  }

  memcpy(model->inputs[0].data, observation, AI_PLANE_IN_1_SIZE_BYTES);
  memcpy(model->inputs[1].data, history, AI_PLANE_IN_2_SIZE_BYTES);

  const uint32_t start_cycles = DWT->CYCCNT;
  const ai_i32 batches = mode == WBR_HIL_MODE_PLANE
                             ? ai_plane_run(model->handle, model->inputs, model->outputs)
                             : ai_jump_run(model->handle, model->inputs, model->outputs);
  const uint32_t elapsed_cycles = DWT->CYCCNT - start_cycles;
  *inference_us = cycles_to_microseconds(elapsed_cycles);
  if (batches != 1) {
    return false;
  }

  memcpy(action, model->outputs[0].data, AI_PLANE_OUT_1_SIZE_BYTES);
  for (size_t i = 0U; i < WBR_HIL_ACTION_DIM; ++i) {
    if (!isfinite(action[i])) {
      return false;
    }
    if (action[i] > 100.0F) {
      action[i] = 100.0F;
    } else if (action[i] < -100.0F) {
      action[i] = -100.0F;
    }
  }
  return true;
}
