#include "wbr_hil_engine.h"

#include <math.h>
#include <string.h>

_Static_assert(sizeof(float) == 4U, "WBR HIL requires 32-bit float");
_Static_assert(WBR_HIL_INFER_REQ_SIZE == 8U + 4U * (WBR_HIL_OBS_DIM + WBR_HIL_HISTORY_DIM),
               "infer request layout changed");
_Static_assert(WBR_HIL_INFER_RSP_SIZE == 16U + 4U * WBR_HIL_ACTION_DIM,
               "infer response layout changed");

static float get_f32_le(const uint8_t *data) {
  const uint32_t bits = wbr_hil_get_u32_le(data);
  float value = 0.0F;
  memcpy(&value, &bits, sizeof(value));
  return value;
}

static void put_f32_le(uint8_t *data, float value) {
  uint32_t bits = 0U;
  memcpy(&bits, &value, sizeof(bits));
  wbr_hil_put_u32_le(data, bits);
}

static bool send_payload(
    wbr_hil_engine_t *engine,
    uint8_t type,
    uint32_t sequence,
    const uint8_t *payload,
    uint16_t payload_length) {
  const size_t frame_length = wbr_hil_frame_encode(
      type,
      sequence,
      payload,
      payload_length,
      engine->response_frame,
      sizeof(engine->response_frame));
  if (frame_length == 0U || engine->write == NULL ||
      !engine->write(engine->write_context, engine->response_frame, frame_length)) {
    engine->transport_ok = false;
    return false;
  }
  return true;
}

static uint32_t request_session(const wbr_hil_engine_t *engine, const wbr_hil_frame_view_t *frame) {
  if (frame->payload_length >= 4U) {
    return wbr_hil_get_u32_le(frame->payload);
  }
  return engine->session_active ? engine->session : 0U;
}

static void send_error(
    wbr_hil_engine_t *engine,
    const wbr_hil_frame_view_t *frame,
    uint32_t session,
    uint32_t code,
    uint32_t detail) {
  uint8_t *payload = engine->response_payload;
  wbr_hil_put_u32_le(payload + 0U, session);
  wbr_hil_put_u32_le(payload + 4U, code);
  wbr_hil_put_u32_le(payload + 8U, detail);
  wbr_hil_put_u32_le(payload + 12U, frame->sequence);
  engine->session_active = false;
  engine->session = 0U;
  (void)send_payload(engine, WBR_HIL_MSG_ERROR, frame->sequence, payload, WBR_HIL_ERROR_SIZE);
}

static uint32_t length_detail(uint16_t expected, uint16_t actual) {
  return ((uint32_t)expected << 16U) | actual;
}

static void handle_hello(wbr_hil_engine_t *engine, const wbr_hil_frame_view_t *frame) {
  if (frame->payload_length != WBR_HIL_HELLO_REQ_SIZE) {
    send_error(
        engine,
        frame,
        request_session(engine, frame),
        WBR_HIL_ERROR_BAD_LENGTH,
        length_detail(WBR_HIL_HELLO_REQ_SIZE, frame->payload_length));
    return;
  }

  const uint32_t session = wbr_hil_get_u32_le(frame->payload + 0U);
  const uint32_t period_us = wbr_hil_get_u32_le(frame->payload + 4U);
  const uint32_t model_set = wbr_hil_get_u32_le(frame->payload + 8U);
  const uint32_t flags = wbr_hil_get_u32_le(frame->payload + 12U);

  engine->session_active = false;
  engine->session = 0U;

  uint32_t status = WBR_HIL_HELLO_OK;
  if (session == 0U) {
    status = WBR_HIL_HELLO_BAD_SESSION;
  } else if (period_us != WBR_HIL_POLICY_PERIOD_US) {
    status = WBR_HIL_HELLO_BAD_PERIOD;
  } else if (model_set != WBR_HIL_MODEL_SET_ID) {
    status = WBR_HIL_HELLO_BAD_MODEL_SET;
  } else if (flags != WBR_HIL_STRICT_FLAGS) {
    status = WBR_HIL_HELLO_BAD_FLAGS;
  } else if (!engine->ai_ready || engine->infer == NULL) {
    status = WBR_HIL_HELLO_AI_UNAVAILABLE;
  }

  uint8_t *payload = engine->response_payload;
  wbr_hil_put_u32_le(payload + 0U, session);
  wbr_hil_put_u32_le(payload + 4U, WBR_HIL_CAPABILITIES);
  wbr_hil_put_u32_le(payload + 8U, WBR_HIL_MODEL_SET_ID);
  wbr_hil_put_u32_le(payload + 12U, WBR_HIL_POLICY_PERIOD_US);
  wbr_hil_put_u32_le(payload + 16U, status);
  wbr_hil_put_u16_le(payload + 20U, WBR_HIL_OBS_DIM);
  wbr_hil_put_u16_le(payload + 22U, WBR_HIL_HISTORY_DIM);
  wbr_hil_put_u16_le(payload + 24U, WBR_HIL_ACTION_DIM);
  wbr_hil_put_u16_le(payload + 26U, WBR_HIL_MODE_MASK);
  wbr_hil_put_u16_le(payload + 28U, (uint16_t)WBR_HIL_MAX_PAYLOAD);
  wbr_hil_put_u16_le(payload + 30U, WBR_HIL_VERSION);
  (void)send_payload(
      engine, WBR_HIL_MSG_HELLO_RSP, frame->sequence, payload, WBR_HIL_HELLO_RSP_SIZE);

  if (status == WBR_HIL_HELLO_OK && engine->transport_ok) {
    engine->session = session;
    engine->last_sequence = frame->sequence;
    engine->session_active = true;
  }
}

static bool decode_inference_input(wbr_hil_engine_t *engine, const wbr_hil_frame_view_t *frame) {
  for (size_t i = 0U; i < (size_t)(WBR_HIL_OBS_DIM + WBR_HIL_HISTORY_DIM); ++i) {
    const float value = get_f32_le(frame->payload + 8U + 4U * i);
    if (!isfinite(value)) {
      send_error(
          engine,
          frame,
          request_session(engine, frame),
          WBR_HIL_ERROR_NONFINITE_INPUT,
          (uint32_t)i);
      return false;
    }
    engine->input[i] = value;
  }
  return true;
}

static void handle_infer(wbr_hil_engine_t *engine, const wbr_hil_frame_view_t *frame) {
  if (frame->payload_length != WBR_HIL_INFER_REQ_SIZE) {
    send_error(
        engine,
        frame,
        request_session(engine, frame),
        WBR_HIL_ERROR_BAD_LENGTH,
        length_detail(WBR_HIL_INFER_REQ_SIZE, frame->payload_length));
    return;
  }

  const uint32_t session = wbr_hil_get_u32_le(frame->payload + 0U);
  const uint8_t mode = frame->payload[4];
  if (!engine->session_active) {
    send_error(engine, frame, session, WBR_HIL_ERROR_HANDSHAKE_REQUIRED, 0U);
    return;
  }
  if (session != engine->session) {
    send_error(engine, frame, session, WBR_HIL_ERROR_SESSION_MISMATCH, engine->session);
    return;
  }
  if (frame->sequence != engine->last_sequence + 1U) {
    send_error(engine, frame, session, WBR_HIL_ERROR_STALE_SEQUENCE, engine->last_sequence);
    return;
  }
  if (mode != WBR_HIL_MODE_PLANE && mode != WBR_HIL_MODE_JUMP) {
    send_error(engine, frame, session, WBR_HIL_ERROR_BAD_MODE, mode);
    return;
  }
  if (frame->payload[5] != 0U || frame->payload[6] != 0U || frame->payload[7] != 0U) {
    const uint32_t reserved = (uint32_t)frame->payload[5] |
                              ((uint32_t)frame->payload[6] << 8U) |
                              ((uint32_t)frame->payload[7] << 16U);
    send_error(engine, frame, session, WBR_HIL_ERROR_BAD_RESERVED, reserved);
    return;
  }
  if (!decode_inference_input(engine, frame)) {
    return;
  }

  memset(engine->action, 0, sizeof(engine->action));
  uint32_t inference_us = 0U;
  uint8_t status = WBR_HIL_INFER_OK;
  if (engine->infer == NULL ||
      !engine->infer(
          engine->infer_context,
          mode,
          engine->input,
          engine->input + WBR_HIL_OBS_DIM,
          engine->action,
          &inference_us)) {
    memset(engine->action, 0, sizeof(engine->action));
    status = WBR_HIL_INFER_AI_FAILURE;
  }

  if (status == WBR_HIL_INFER_OK) {
    for (size_t i = 0U; i < WBR_HIL_ACTION_DIM; ++i) {
      if (!isfinite(engine->action[i])) {
        memset(engine->action, 0, sizeof(engine->action));
        status = WBR_HIL_INFER_AI_FAILURE;
        break;
      }
      if (engine->action[i] > 100.0F) {
        engine->action[i] = 100.0F;
      } else if (engine->action[i] < -100.0F) {
        engine->action[i] = -100.0F;
      }
    }
  }

  uint8_t *payload = engine->response_payload;
  wbr_hil_put_u32_le(payload + 0U, session);
  wbr_hil_put_u32_le(payload + 4U, frame->sequence);
  payload[8] = mode;
  payload[9] = status;
  wbr_hil_put_u16_le(payload + 10U, 0U);
  wbr_hil_put_u32_le(payload + 12U, inference_us);
  for (size_t i = 0U; i < WBR_HIL_ACTION_DIM; ++i) {
    put_f32_le(payload + 16U + 4U * i, engine->action[i]);
  }

  engine->last_sequence = frame->sequence;
  (void)send_payload(
      engine, WBR_HIL_MSG_INFER_RSP, frame->sequence, payload, WBR_HIL_INFER_RSP_SIZE);
}

static void handle_frame(void *context, const wbr_hil_frame_view_t *frame) {
  wbr_hil_engine_t *engine = (wbr_hil_engine_t *)context;
  if (!engine->transport_ok) {
    return;
  }

  switch (frame->type) {
    case WBR_HIL_MSG_HELLO_REQ:
      handle_hello(engine, frame);
      break;
    case WBR_HIL_MSG_INFER_REQ:
      handle_infer(engine, frame);
      break;
    default:
      send_error(
          engine,
          frame,
          request_session(engine, frame),
          WBR_HIL_ERROR_BAD_TYPE,
          frame->type);
      break;
  }
}

void wbr_hil_engine_init(
    wbr_hil_engine_t *engine,
    wbr_hil_infer_callback_t infer,
    void *infer_context,
    wbr_hil_write_callback_t write,
    void *write_context,
    bool ai_ready) {
  if (engine == NULL) {
    return;
  }
  memset(engine, 0, sizeof(*engine));
  engine->infer = infer;
  engine->infer_context = infer_context;
  engine->write = write;
  engine->write_context = write_context;
  engine->ai_ready = ai_ready;
  engine->transport_ok = true;
  wbr_hil_parser_reset(&engine->parser);
}

void wbr_hil_engine_reset_link(wbr_hil_engine_t *engine) {
  if (engine == NULL) {
    return;
  }
  wbr_hil_parser_reset(&engine->parser);
  engine->session_active = false;
  engine->transport_ok = true;
  engine->session = 0U;
  engine->last_sequence = 0U;
  memset(engine->input, 0, sizeof(engine->input));
  memset(engine->action, 0, sizeof(engine->action));
}

bool wbr_hil_engine_feed(wbr_hil_engine_t *engine, const uint8_t *data, size_t length) {
  if (engine == NULL || (length > 0U && data == NULL)) {
    return false;
  }
  engine->transport_ok = true;
  (void)wbr_hil_parser_feed(&engine->parser, data, length, handle_frame, engine);
  return engine->transport_ok;
}
