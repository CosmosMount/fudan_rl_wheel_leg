#ifndef WBR_HIL_ENGINE_H
#define WBR_HIL_ENGINE_H

#include "wbr_hil_protocol.h"

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define WBR_HIL_POLICY_PERIOD_US UINT32_C(10000)
#define WBR_HIL_MODEL_SET_ID UINT32_C(0x1C28E40F)
#define WBR_HIL_CAPABILITIES UINT32_C(0x0000000F)
#define WBR_HIL_STRICT_FLAGS UINT32_C(1)
#define WBR_HIL_OBS_DIM UINT16_C(25)
#define WBR_HIL_HISTORY_DIM UINT16_C(125)
#define WBR_HIL_ACTION_DIM UINT16_C(6)
#define WBR_HIL_MODE_MASK UINT16_C(3)

#define WBR_HIL_HELLO_REQ_SIZE UINT16_C(16)
#define WBR_HIL_HELLO_RSP_SIZE UINT16_C(32)
#define WBR_HIL_INFER_REQ_SIZE UINT16_C(608)
#define WBR_HIL_INFER_RSP_SIZE UINT16_C(40)
#define WBR_HIL_ERROR_SIZE UINT16_C(16)

enum {
  WBR_HIL_MODE_PLANE = 0,
  WBR_HIL_MODE_JUMP = 1,
};

enum {
  WBR_HIL_HELLO_OK = 0,
  WBR_HIL_HELLO_BAD_SESSION = 1,
  WBR_HIL_HELLO_BAD_PERIOD = 2,
  WBR_HIL_HELLO_BAD_MODEL_SET = 3,
  WBR_HIL_HELLO_BAD_FLAGS = 4,
  WBR_HIL_HELLO_AI_UNAVAILABLE = 5,
};

enum {
  WBR_HIL_INFER_OK = 0,
  WBR_HIL_INFER_AI_FAILURE = 1,
};

enum {
  WBR_HIL_ERROR_BAD_LENGTH = 1,
  WBR_HIL_ERROR_BAD_TYPE = 2,
  WBR_HIL_ERROR_HANDSHAKE_REQUIRED = 3,
  WBR_HIL_ERROR_SESSION_MISMATCH = 4,
  WBR_HIL_ERROR_STALE_SEQUENCE = 5,
  WBR_HIL_ERROR_BAD_MODE = 6,
  WBR_HIL_ERROR_BAD_RESERVED = 7,
  WBR_HIL_ERROR_NONFINITE_INPUT = 8,
};

typedef bool (*wbr_hil_infer_callback_t)(
    void *context,
    uint8_t mode,
    const float observation[WBR_HIL_OBS_DIM],
    const float history[WBR_HIL_HISTORY_DIM],
    float action[WBR_HIL_ACTION_DIM],
    uint32_t *inference_us);

typedef bool (*wbr_hil_write_callback_t)(void *context, const uint8_t *data, size_t length);

typedef struct {
  wbr_hil_parser_t parser;
  wbr_hil_infer_callback_t infer;
  void *infer_context;
  wbr_hil_write_callback_t write;
  void *write_context;
  bool ai_ready;
  bool session_active;
  bool transport_ok;
  uint32_t session;
  uint32_t last_sequence;
  float input[WBR_HIL_OBS_DIM + WBR_HIL_HISTORY_DIM];
  float action[WBR_HIL_ACTION_DIM];
  uint8_t response_payload[WBR_HIL_INFER_RSP_SIZE];
  uint8_t response_frame[WBR_HIL_HEADER_SIZE + WBR_HIL_INFER_RSP_SIZE + WBR_HIL_CRC_SIZE];
} wbr_hil_engine_t;

void wbr_hil_engine_init(
    wbr_hil_engine_t *engine,
    wbr_hil_infer_callback_t infer,
    void *infer_context,
    wbr_hil_write_callback_t write,
    void *write_context,
    bool ai_ready);

void wbr_hil_engine_reset_link(wbr_hil_engine_t *engine);
bool wbr_hil_engine_feed(wbr_hil_engine_t *engine, const uint8_t *data, size_t length);

#ifdef __cplusplus
}
#endif

#endif
