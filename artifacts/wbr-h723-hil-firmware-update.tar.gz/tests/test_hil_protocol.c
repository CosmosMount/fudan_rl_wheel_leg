#include "wbr_hil_engine.h"
#include "wbr_hil_protocol.h"

#include <assert.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef struct {
  unsigned count;
  uint8_t type;
  uint16_t payload_length;
  uint32_t sequence;
  uint8_t payload[WBR_HIL_MAX_PAYLOAD];
} parsed_frame_t;

typedef struct {
  unsigned count;
  uint8_t bytes[64];
  size_t length;
} writer_capture_t;

static const uint8_t k_canonical_hello[] = {
    0x57, 0x52, 0x4C, 0x31, 0x01, 0x01, 0x10, 0x00, 0x01, 0x00,
    0x00, 0x00, 0x44, 0x33, 0x22, 0x11, 0x10, 0x27, 0x00, 0x00,
    0x0F, 0xE4, 0x28, 0x1C, 0x01, 0x00, 0x00, 0x00, 0x41, 0x67,
};

static void capture_frame(void *context, const wbr_hil_frame_view_t *frame) {
  parsed_frame_t *capture = (parsed_frame_t *)context;
  ++capture->count;
  capture->type = frame->type;
  capture->payload_length = frame->payload_length;
  capture->sequence = frame->sequence;
  if (frame->payload_length > 0U) {
    memcpy(capture->payload, frame->payload, frame->payload_length);
  }
}

static bool capture_write(void *context, const uint8_t *data, size_t length) {
  writer_capture_t *capture = (writer_capture_t *)context;
  assert(length <= sizeof(capture->bytes));
  memcpy(capture->bytes, data, length);
  capture->length = length;
  ++capture->count;
  return true;
}

static bool fake_infer(
    void *context,
    uint8_t mode,
    const float observation[WBR_HIL_OBS_DIM],
    const float history[WBR_HIL_HISTORY_DIM],
    float action[WBR_HIL_ACTION_DIM],
    uint32_t *inference_us) {
  unsigned *calls = (unsigned *)context;
  ++*calls;
  assert(mode == WBR_HIL_MODE_PLANE || mode == WBR_HIL_MODE_JUMP);
  action[0] = observation[0];
  action[1] = history[0];
  action[2] = 101.0F;
  action[3] = -101.0F;
  action[4] = 0.5F;
  action[5] = -0.5F;
  *inference_us = 321U;
  return true;
}

static void put_f32(uint8_t *data, float value) {
  uint32_t bits = 0U;
  memcpy(&bits, &value, sizeof(bits));
  wbr_hil_put_u32_le(data, bits);
}

static float get_f32(const uint8_t *data) {
  const uint32_t bits = wbr_hil_get_u32_le(data);
  float value = 0.0F;
  memcpy(&value, &bits, sizeof(value));
  return value;
}

static size_t make_hello(uint32_t sequence, uint32_t session, uint8_t *frame) {
  uint8_t payload[WBR_HIL_HELLO_REQ_SIZE];
  wbr_hil_put_u32_le(payload + 0U, session);
  wbr_hil_put_u32_le(payload + 4U, WBR_HIL_POLICY_PERIOD_US);
  wbr_hil_put_u32_le(payload + 8U, WBR_HIL_MODEL_SET_ID);
  wbr_hil_put_u32_le(payload + 12U, WBR_HIL_STRICT_FLAGS);
  return wbr_hil_frame_encode(
      WBR_HIL_MSG_HELLO_REQ,
      sequence,
      payload,
      WBR_HIL_HELLO_REQ_SIZE,
      frame,
      WBR_HIL_MAX_FRAME_SIZE);
}

static size_t make_infer(
    uint32_t sequence,
    uint32_t session,
    uint8_t mode,
    uint8_t reserved,
    float first_observation,
    float first_history,
    uint8_t *frame) {
  uint8_t payload[WBR_HIL_INFER_REQ_SIZE];
  memset(payload, 0, sizeof(payload));
  wbr_hil_put_u32_le(payload + 0U, session);
  payload[4] = mode;
  payload[5] = reserved;
  for (size_t i = 0U; i < WBR_HIL_OBS_DIM + WBR_HIL_HISTORY_DIM; ++i) {
    put_f32(payload + 8U + 4U * i, (float)i * 0.01F);
  }
  put_f32(payload + 8U, first_observation);
  put_f32(payload + 8U + 4U * WBR_HIL_OBS_DIM, first_history);
  return wbr_hil_frame_encode(
      WBR_HIL_MSG_INFER_REQ,
      sequence,
      payload,
      WBR_HIL_INFER_REQ_SIZE,
      frame,
      WBR_HIL_MAX_FRAME_SIZE);
}

static parsed_frame_t parse_one(const uint8_t *data, size_t length) {
  wbr_hil_parser_t parser;
  parsed_frame_t parsed;
  memset(&parsed, 0, sizeof(parsed));
  wbr_hil_parser_reset(&parser);
  assert(wbr_hil_parser_feed(&parser, data, length, capture_frame, &parsed) == 1U);
  assert(parsed.count == 1U);
  return parsed;
}

static void test_crc_and_golden_hello(void) {
  static const uint8_t crc_input[] = "123456789";
  assert(wbr_hil_crc16(crc_input, sizeof(crc_input) - 1U) == UINT16_C(0x6F91));

  uint8_t encoded[WBR_HIL_MAX_FRAME_SIZE];
  const size_t length = make_hello(1U, UINT32_C(0x11223344), encoded);
  assert(length == sizeof(k_canonical_hello));
  assert(memcmp(encoded, k_canonical_hello, sizeof(k_canonical_hello)) == 0);

  for (size_t split = 0U; split <= length; ++split) {
    wbr_hil_parser_t parser;
    parsed_frame_t parsed;
    memset(&parsed, 0, sizeof(parsed));
    wbr_hil_parser_reset(&parser);
    size_t emitted = wbr_hil_parser_feed(&parser, encoded, split, capture_frame, &parsed);
    emitted += wbr_hil_parser_feed(
        &parser, encoded + split, length - split, capture_frame, &parsed);
    assert(emitted == 1U);
    assert(parsed.count == 1U);
    assert(parsed.type == WBR_HIL_MSG_HELLO_REQ);
    assert(parsed.payload_length == WBR_HIL_HELLO_REQ_SIZE);
    assert(parsed.sequence == 1U);
  }
}

static void test_hello_sync_barrier_recovers_partial_infer(void) {
  uint8_t infer[WBR_HIL_MAX_FRAME_SIZE];
  const size_t infer_length = make_infer(
      2U, UINT32_C(0x11223344), WBR_HIL_MODE_PLANE, 0U, 0.0F, 0.0F, infer);
  assert(infer_length == WBR_HIL_MAX_FRAME_SIZE);

  for (size_t partial_length = 1U; partial_length < infer_length; ++partial_length) {
    wbr_hil_engine_t engine;
    writer_capture_t writer;
    unsigned inference_calls = 0U;
    memset(&writer, 0, sizeof(writer));
    wbr_hil_engine_init(
        &engine, fake_infer, &inference_calls, capture_write, &writer, true);

    assert(wbr_hil_engine_feed(&engine, infer, partial_length));
    assert(writer.count == 0U);

    size_t minimum_discard = partial_length;
    if (partial_length == infer_length / 2U) {
      uint8_t bad_hello[sizeof(k_canonical_hello)];
      memcpy(bad_hello, k_canonical_hello, sizeof(bad_hello));
      bad_hello[sizeof(bad_hello) - 1U] ^= 1U;
      assert(wbr_hil_engine_feed(&engine, bad_hello, sizeof(bad_hello)));
      assert(writer.count == 0U);
      minimum_discard += sizeof(bad_hello);
    }

    assert(wbr_hil_engine_feed(
        &engine, k_canonical_hello, sizeof(k_canonical_hello)));
    assert(writer.count == 1U);
    const parsed_frame_t response = parse_one(writer.bytes, writer.length);
    assert(response.type == WBR_HIL_MSG_HELLO_RSP);
    assert(response.sequence == 1U);
    assert(wbr_hil_get_u32_le(response.payload + 0U) == UINT32_C(0x11223344));
    assert(wbr_hil_get_u32_le(response.payload + 16U) == WBR_HIL_HELLO_OK);
    assert(engine.session_active);
    assert(engine.session == UINT32_C(0x11223344));
    assert(engine.parser.used == 0U);
    assert(engine.parser.discarded_bytes >= minimum_discard);
    assert(inference_calls == 0U);
  }
}

static void test_parser_resynchronization(void) {
  uint8_t valid[WBR_HIL_MAX_FRAME_SIZE];
  const size_t valid_length = make_hello(7U, UINT32_C(0x12345678), valid);

  uint8_t bad_crc[WBR_HIL_MAX_FRAME_SIZE];
  memcpy(bad_crc, valid, valid_length);
  bad_crc[12] ^= 0x80U;

  uint8_t unknown_type[WBR_HIL_MAX_FRAME_SIZE];
  memcpy(unknown_type, valid, valid_length);
  unknown_type[5] = 9U;
  wbr_hil_put_u16_le(
      unknown_type + valid_length - 2U, wbr_hil_crc16(unknown_type, valid_length - 2U));

  uint8_t stream[3U + 2U * WBR_HIL_MAX_FRAME_SIZE];
  const uint8_t garbage[] = {0x99U, 0x57U, 0x00U};
  memcpy(stream, garbage, sizeof(garbage));
  memcpy(stream + sizeof(garbage), bad_crc, valid_length);
  memcpy(stream + sizeof(garbage) + valid_length, valid, valid_length);

  wbr_hil_parser_t parser;
  parsed_frame_t parsed;
  memset(&parsed, 0, sizeof(parsed));
  wbr_hil_parser_reset(&parser);
  const size_t stream_length = sizeof(garbage) + 2U * valid_length;
  for (size_t offset = 0U; offset < stream_length; offset += 7U) {
    const size_t chunk = stream_length - offset < 7U ? stream_length - offset : 7U;
    (void)wbr_hil_parser_feed(&parser, stream + offset, chunk, capture_frame, &parsed);
  }
  assert(parsed.count == 1U);
  assert(parser.bad_crcs == 1U);
  assert(parser.discarded_bytes >= sizeof(garbage));

  memset(&parsed, 0, sizeof(parsed));
  wbr_hil_parser_reset(&parser);
  memcpy(stream, unknown_type, valid_length);
  memcpy(stream + valid_length, valid, valid_length);
  assert(wbr_hil_parser_feed(
             &parser, stream, 2U * valid_length, capture_frame, &parsed) == 1U);
  assert(parsed.count == 1U);
  assert(parser.bad_headers == 1U);

  uint8_t maximum_payload[WBR_HIL_MAX_PAYLOAD];
  memset(maximum_payload, 0xA5, sizeof(maximum_payload));
  uint8_t maximum_frame[WBR_HIL_MAX_FRAME_SIZE];
  const size_t maximum_length = wbr_hil_frame_encode(
      WBR_HIL_MSG_INFER_REQ,
      1U,
      maximum_payload,
      (uint16_t)sizeof(maximum_payload),
      maximum_frame,
      sizeof(maximum_frame));
  assert(maximum_length == WBR_HIL_MAX_FRAME_SIZE);
  memset(&parsed, 0, sizeof(parsed));
  wbr_hil_parser_reset(&parser);
  assert(wbr_hil_parser_feed(
             &parser, maximum_frame, maximum_length, capture_frame, &parsed) == 1U);
  assert(parsed.payload_length == WBR_HIL_MAX_PAYLOAD);
  assert(wbr_hil_frame_encode(
             WBR_HIL_MSG_INFER_REQ,
             1U,
             maximum_payload,
             (uint16_t)sizeof(maximum_payload),
             maximum_frame,
             sizeof(maximum_frame) - 1U) == 0U);
}

static void establish_session(
    wbr_hil_engine_t *engine,
    writer_capture_t *writer,
    uint32_t sequence,
    uint32_t session) {
  uint8_t hello[WBR_HIL_MAX_FRAME_SIZE];
  const size_t hello_length = make_hello(sequence, session, hello);
  assert(wbr_hil_engine_feed(engine, hello, hello_length));
  const parsed_frame_t response = parse_one(writer->bytes, writer->length);
  assert(response.type == WBR_HIL_MSG_HELLO_RSP);
  assert(response.sequence == sequence);
  assert(response.payload_length == WBR_HIL_HELLO_RSP_SIZE);
  assert(wbr_hil_get_u32_le(response.payload + 0U) == session);
  assert(wbr_hil_get_u32_le(response.payload + 4U) == WBR_HIL_CAPABILITIES);
  assert(wbr_hil_get_u32_le(response.payload + 8U) == WBR_HIL_MODEL_SET_ID);
  assert(wbr_hil_get_u32_le(response.payload + 12U) == WBR_HIL_POLICY_PERIOD_US);
  assert(wbr_hil_get_u32_le(response.payload + 16U) == WBR_HIL_HELLO_OK);
  assert(wbr_hil_get_u16_le(response.payload + 20U) == WBR_HIL_OBS_DIM);
  assert(wbr_hil_get_u16_le(response.payload + 22U) == WBR_HIL_HISTORY_DIM);
  assert(wbr_hil_get_u16_le(response.payload + 24U) == WBR_HIL_ACTION_DIM);
  assert(wbr_hil_get_u16_le(response.payload + 26U) == WBR_HIL_MODE_MASK);
  assert(wbr_hil_get_u16_le(response.payload + 28U) == WBR_HIL_MAX_PAYLOAD);
  assert(wbr_hil_get_u16_le(response.payload + 30U) == WBR_HIL_VERSION);
}

static void assert_error(
    const writer_capture_t *writer,
    uint32_t header_sequence,
    uint32_t session,
    uint32_t code,
    uint32_t offending_sequence) {
  const parsed_frame_t response = parse_one(writer->bytes, writer->length);
  assert(response.type == WBR_HIL_MSG_ERROR);
  assert(response.sequence == header_sequence);
  assert(response.payload_length == WBR_HIL_ERROR_SIZE);
  assert(wbr_hil_get_u32_le(response.payload + 0U) == session);
  assert(wbr_hil_get_u32_le(response.payload + 4U) == code);
  assert(wbr_hil_get_u32_le(response.payload + 12U) == offending_sequence);
}

static void test_engine_handshake_inference_and_fail_closed_errors(void) {
  wbr_hil_engine_t engine;
  writer_capture_t writer;
  unsigned inference_calls = 0U;
  memset(&writer, 0, sizeof(writer));
  wbr_hil_engine_init(
      &engine, fake_infer, &inference_calls, capture_write, &writer, true);

  static const uint8_t golden_hello_response[] = {
      0x57, 0x52, 0x4C, 0x31, 0x01, 0x02, 0x20, 0x00, 0x07, 0x00,
      0x00, 0x00, 0x78, 0x56, 0x34, 0x12, 0x0F, 0x00, 0x00, 0x00,
      0x0F, 0xE4, 0x28, 0x1C, 0x10, 0x27, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x19, 0x00, 0x7D, 0x00, 0x06, 0x00, 0x03, 0x00,
      0x60, 0x02, 0x01, 0x00, 0x27, 0x2D,
  };
  establish_session(&engine, &writer, 7U, UINT32_C(0x12345678));
  assert(writer.length == sizeof(golden_hello_response));
  assert(memcmp(writer.bytes, golden_hello_response, sizeof(golden_hello_response)) == 0);

  uint8_t infer[WBR_HIL_MAX_FRAME_SIZE];
  size_t infer_length = make_infer(
      8U, UINT32_C(0x12345678), WBR_HIL_MODE_PLANE, 0U, 1.25F, -2.5F, infer);
  for (size_t offset = 0U; offset < infer_length; offset += 13U) {
    const size_t chunk = infer_length - offset < 13U ? infer_length - offset : 13U;
    assert(wbr_hil_engine_feed(&engine, infer + offset, chunk));
  }
  assert(inference_calls == 1U);
  parsed_frame_t response = parse_one(writer.bytes, writer.length);
  assert(response.type == WBR_HIL_MSG_INFER_RSP);
  assert(response.sequence == 8U);
  assert(wbr_hil_get_u32_le(response.payload + 0U) == UINT32_C(0x12345678));
  assert(wbr_hil_get_u32_le(response.payload + 4U) == 8U);
  assert(response.payload[8] == WBR_HIL_MODE_PLANE);
  assert(response.payload[9] == WBR_HIL_INFER_OK);
  assert(wbr_hil_get_u16_le(response.payload + 10U) == 0U);
  assert(wbr_hil_get_u32_le(response.payload + 12U) == 321U);
  assert(fabsf(get_f32(response.payload + 16U) - 1.25F) < 1.0e-6F);
  assert(fabsf(get_f32(response.payload + 20U) + 2.5F) < 1.0e-6F);
  assert(get_f32(response.payload + 24U) == 100.0F);
  assert(get_f32(response.payload + 28U) == -100.0F);

  assert(wbr_hil_engine_feed(&engine, infer, infer_length));
  assert(inference_calls == 1U);
  assert_error(
      &writer, 8U, UINT32_C(0x12345678), WBR_HIL_ERROR_STALE_SEQUENCE, 8U);
  assert(!engine.session_active);

  establish_session(&engine, &writer, 20U, UINT32_C(0x12345678));
  infer_length = make_infer(
      21U, UINT32_C(0x87654321), WBR_HIL_MODE_PLANE, 0U, 0.0F, 0.0F, infer);
  assert(wbr_hil_engine_feed(&engine, infer, infer_length));
  assert_error(
      &writer, 21U, UINT32_C(0x87654321), WBR_HIL_ERROR_SESSION_MISMATCH, 21U);
  assert(!engine.session_active);

  establish_session(&engine, &writer, 30U, UINT32_C(0x12345678));
  infer_length = make_infer(
      31U, UINT32_C(0x12345678), WBR_HIL_MODE_JUMP, 0U, NAN, 0.0F, infer);
  assert(wbr_hil_engine_feed(&engine, infer, infer_length));
  assert_error(
      &writer, 31U, UINT32_C(0x12345678), WBR_HIL_ERROR_NONFINITE_INPUT, 31U);
  assert(!engine.session_active);

  establish_session(&engine, &writer, 40U, UINT32_C(0x12345678));
  infer_length = make_infer(
      42U, UINT32_C(0x12345678), WBR_HIL_MODE_PLANE, 0U, 0.0F, 0.0F, infer);
  assert(wbr_hil_engine_feed(&engine, infer, infer_length));
  assert_error(
      &writer, 42U, UINT32_C(0x12345678), WBR_HIL_ERROR_STALE_SEQUENCE, 42U);
  assert(!engine.session_active);

  establish_session(&engine, &writer, UINT32_MAX, UINT32_C(0x12345678));
  infer_length = make_infer(
      0U, UINT32_C(0x12345678), WBR_HIL_MODE_JUMP, 0U, 0.0F, 0.0F, infer);
  assert(wbr_hil_engine_feed(&engine, infer, infer_length));
  response = parse_one(writer.bytes, writer.length);
  assert(response.type == WBR_HIL_MSG_INFER_RSP);
  assert(response.sequence == 0U);
  assert(wbr_hil_get_u32_le(response.payload + 4U) == 0U);
}

static void test_handshake_rejects_unavailable_ai(void) {
  wbr_hil_engine_t engine;
  writer_capture_t writer;
  memset(&writer, 0, sizeof(writer));
  wbr_hil_engine_init(&engine, NULL, NULL, capture_write, &writer, false);
  uint8_t hello[WBR_HIL_MAX_FRAME_SIZE];
  const size_t length = make_hello(1U, 2U, hello);
  assert(wbr_hil_engine_feed(&engine, hello, length));
  const parsed_frame_t response = parse_one(writer.bytes, writer.length);
  assert(response.type == WBR_HIL_MSG_HELLO_RSP);
  assert(response.sequence == 1U);
  assert(wbr_hil_get_u32_le(response.payload + 16U) == WBR_HIL_HELLO_AI_UNAVAILABLE);
  assert(!engine.session_active);
}

int main(void) {
  test_crc_and_golden_hello();
  test_parser_resynchronization();
  test_hello_sync_barrier_recovers_partial_infer();
  test_engine_handshake_inference_and_fail_closed_errors();
  test_handshake_rejects_unavailable_ai();
  puts("wbr_hil_protocol_test: ok");
  return 0;
}
